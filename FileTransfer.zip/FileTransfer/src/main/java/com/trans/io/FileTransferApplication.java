package com.trans.io;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.file.logicClass;
import com.trans.io.constants.Constants;

@SpringBootApplication
public class FileTransferApplication {

	public static void main(String[] args) throws IOException {
		SpringApplication.run(FileTransferApplication.class, args);
		
	}

}
