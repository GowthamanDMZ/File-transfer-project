package com.trans.io.test;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BufferedImage img1;
		BufferedImage img2;
		try {
			img1 = ImageIO.read(new File("G:/gowtham/folder/b104309B.a01"));
			img2 = ImageIO.read(new File("G:/gowtham/folder/b104309B.q01"));
			BufferedImage joinedImg = joinBufferedImage(img1, img2);
		    ImageIO.write(joinedImg, "png", new File("G:/gowtham/folder/joined.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
		
		
	}
	public static BufferedImage joinBufferedImage(BufferedImage img1,
		      BufferedImage img2) {
		    int offset = 2;
		    int width = img1.getWidth() + img2.getWidth() + offset;
		    int height = Math.max(img1.getHeight(), img2.getHeight()) + offset;
		    BufferedImage newImage = new BufferedImage(width, height,
		        BufferedImage.TYPE_INT_ARGB);
		    Graphics2D g2 = newImage.createGraphics();
		    Color oldColor = g2.getColor();
		    g2.setPaint(Color.BLACK);
		    g2.fillRect(0, 0, width, height);
		    g2.setColor(oldColor);
		    g2.drawImage(img1, null, 0, 0);
		    g2.drawImage(img2, null, img1.getWidth() + offset, 0);
		    g2.dispose();
		    return newImage;
		  }

}
