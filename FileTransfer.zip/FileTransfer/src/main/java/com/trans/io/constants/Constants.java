package com.trans.io.constants;

public class Constants {

	public static String csvPath = "G:/gowtham/csvFolder/";
	public static String destFolder = "G:/gowtham/destination/";
	public static String srcFolder = "G:/gowtham/folder/";
}
