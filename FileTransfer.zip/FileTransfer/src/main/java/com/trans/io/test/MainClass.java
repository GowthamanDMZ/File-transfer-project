package com.trans.io.test;

import java.io.File;
import java.util.List;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String csvPath = Constants.csvPath;
		
		logicClass lc = new logicClass();
		List<File> csvFiles = lc.getCSVFiles(csvPath);
		lc.returnFolder(csvFiles);
		
	}

	
	
}
