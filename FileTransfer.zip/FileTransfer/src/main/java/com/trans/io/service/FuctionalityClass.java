package com.trans.io.service;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;

import com.trans.io.constants.Constants;

public class FuctionalityClass {

	public static void main(String[] args) throws IOException {
		getLstFile("filename","docNumber");
	}
	
	// filename = number from csv filename
	//docNum = document number read from csv file
	public static void getLstFile(String filename, String docNum) throws IOException{
		
		/*Get the .lst file with number in the csv file name
		 *Search for doc num and the images in the .lst file
		 *Map with key=docNumber, value=List of image file names
		 */
		
		Map<String, List<String>> lstFileData = new HashMap<String, List<String>>();
		
		//Adding dump data
		lstFileData = addMapData(lstFileData);
		
		for (String key : lstFileData.keySet())  
        { 
            List<String> imgFilList = lstFileData.get(key); 
            List<File> imageFiles = new ArrayList<File>();
            File destFolder = new File(Constants.destFolder + "\\" + key);
    		if (!destFolder.exists()) {
    			destFolder.mkdirs();
            }
    		for(String imgFile : imgFilList){
    			File image = new File(Constants.srcFolder + "\\" + imgFile);
    			File destFile = new File(Constants.destFolder + "\\" + key + "\\" + image.getName()+".PNG");
    			System.out.println(image.getName());
    			Files.copy(image.toPath(), destFile.toPath());
    			
    			imageFiles.add(destFile);
    		}
    		//merge images in the destination folder
    		//getConcatImages(imageFiles, key);
        } 
		
	}
	
	public static void getConcatImages(List<File> imageFiles, String destFolderName) throws IOException{
		
		BufferedImage images[] = new BufferedImage[imageFiles.size()];
		List<BufferedImage> buffImgList = new ArrayList<BufferedImage>();
		
		//creating buffered image list
		for(File imgFile : imageFiles){
			FileInputStream fis = new FileInputStream(imgFile); 
			BufferedImage img1 = ImageIO.read(fis);
			buffImgList.add(img1);
		}
			
		for(BufferedImage bimage: buffImgList){
			Graphics2D g2d = bimage.createGraphics();
            g2d.dispose();
		}
			
		int heightTotal = 0;
		int width = 0;
		for(BufferedImage bimage: buffImgList){
            heightTotal += bimage.getHeight();
            width = bimage.getWidth();
        }
			
		int heightCurr = 0;
        BufferedImage concatImage = new BufferedImage(width, heightTotal, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = concatImage.createGraphics();
        for(BufferedImage bimage: buffImgList){
            g2d.drawImage(bimage, 0, heightCurr, null);
            heightCurr += bimage.getHeight();
        }
        g2d.dispose();
        
        ImageIO.write(concatImage, "png", new File(Constants.destFolder + "\\" + destFolderName + "\\"  + "concat.PNG")); // export concat image
        //ImageIO.write(images[0], "png", new File(Constants.destFolder + "\\" + destFolderName + "\\" + image.getName() + "single.png")); 
        
	}
	
	 public static Map<String, List<String>> addMapData(Map<String, List<String>> lstFileData){
		 List<String> l = new ArrayList<String>();
		 List<String> l2 = new ArrayList<String>();
		 List<String> l3 = new ArrayList<String>();
		 
		 l.add("b104309B.q01");
		 l.add("b104309B.a01");
		 
		 l2.add("b104309B.q01");
		 l2.add("b104309B.a01");
		 
		 l3.add("b104309B.q01");
		 l3.add("b104309B.a01");
		 
		 lstFileData.put("19043109AA", l);
		 lstFileData.put("19043109AB", l2);
		 lstFileData.put("19043109AC", l3);
		 
		 return lstFileData;
	 }
	
	 
	
	
}
