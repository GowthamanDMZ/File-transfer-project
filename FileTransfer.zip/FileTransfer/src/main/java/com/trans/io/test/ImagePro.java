package com.trans.io.test;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;

import javax.imageio.ImageIO;

public class ImagePro {

	public static void main(String[] args) throws Exception{
		
		
		int imagesCount = 2;
        BufferedImage images[] = new BufferedImage[imagesCount];
        //File file = new File("G:/gowtham/folder/certified.JPG");
        File file = new File("G:/gowtham/destination/19043109AA/b104309BGows.PNG");
        
        File file1 = new File("G:/gowtham/folder/pending.JPG");
        FileInputStream fis = new FileInputStream(file); 
		BufferedImage img1 = ImageIO.read(fis);
		FileInputStream fis1 = new FileInputStream(file1); 
		BufferedImage img2 = ImageIO.read(fis1);
		BufferedImage temp = img1;
        for(int j = 0; j < images.length; j++) {
            images[j] = temp;
            Graphics2D g2d = images[j].createGraphics();
            g2d.dispose();
            temp = img2;
        } 
        
        int heightTotal = 0;
        for(int j = 0; j < images.length; j++) {
            heightTotal += images[j].getHeight();
        }
        
        int heightCurr = 0;
        BufferedImage concatImage = new BufferedImage(img2.getWidth(), heightTotal, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = concatImage.createGraphics();
        for(int j = 0; j < images.length; j++) {
            g2d.drawImage(images[j], 0, heightCurr, null);
            heightCurr += images[j].getHeight();
        }
        g2d.dispose();
        
        ImageIO.write(concatImage, "png", new File("G:/gowtham/folder/concat.png")); // export concat image
        //ImageIO.write(images[0], "png", new File("G:/gowtham/single.png")); 
	}
	
	
	
	public void getConcatImage(){
		
	}
	
}
