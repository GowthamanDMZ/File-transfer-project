package com.trans.io.test;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Files;


public class ImageProcess {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub

			/*File file = new File("G:/gowtham/b104309BA");
			BufferedImage img1 = ImageIO.read(file);
			  
			  BufferedReader br = new BufferedReader(new FileReader(file)); 
			  FileWriter fw = new FileWriter("G:/gowtham/b104309BGo");
	          BufferedWriter WriteFileBuffer = new BufferedWriter(fw);
			  String st; 
			  while ((st = br.readLine()) != null) {
				  WriteFileBuffer.write(st);
			  }
			  WriteFileBuffer.close();*/
				File file = new File("G:/gowtham/b104309BA");
				File file1 = new File("G:/gowtham/two.TIF");
				// ...(file is initialised)...
				byte[] fileContent = Files.readAllBytes(file.toPath());
				byte[] fileContent1 = Files.readAllBytes(file1.toPath());

				byte[] one = fileContent;
				byte[] two = fileContent1;
				byte[] combined = new byte[one.length + two.length];

				
				/*RandomAccessFile stream = new RandomAccessFile("G:/gowtham/b104309BGoo", "rw");
			    FileChannel channel = stream.getChannel();
			    ByteBuffer buffer = ByteBuffer.allocate(one.length);
			    ByteBuffer buffer1 = ByteBuffer.allocate(two.length);
			    buffer.put(fileContent);
			    buffer.flip();
			    channel.write(buffer);
			    buffer1.put(fileContent1);
			    buffer1.flip();
			    channel.write(buffer1, two.length);
			    stream.close();
			    channel.close();*/
				
				FileOutputStream out = new FileOutputStream("G:/gowtham/b104309BG");
				out.write(fileContent);
				out.write(combined);
				out.close();
				
				FileOutputStream fos = new FileOutputStream("G:/gowtham/some", true);
			    fos.write("Appended".getBytes());
			    fos.close();
				
				/*DataOutputStream outStream = new DataOutputStream(new FileOutputStream("G:/gowtham/b104309BGo"));
			    outStream.write(fileContent);
			    outStream.close();*/
				
				
			  /*FileInputStream fin=new FileInputStream("G:/gowtham/b104309BA");    
			  int i=0;    
	            while((i=fin.read())!=-1){    
	             System.out.print((char)i);    
	            }    
	            fin.close();   */
			  
			  
			  
			  /*System.out.println(st); 
			    
			  
	        File[] files = file.listFiles();
	        try {
		        for(File f: files){
		            System.out.println(f.getName());
		            BufferedImage img11 = ImageIO.read(f);
				    BufferedImage img2 = ImageIO.read(new File("G:/gowtham/b104309B.JPG"));
				    BufferedImage joinedImg = joinBufferedImage(img1, img2);
				    ImageIO.write(joinedImg, "png", new File("G:/gowtham/joined.png")); 
		        }
	        }catch(Exception e) {
	        	System.out.println("no files");
	        }      */
	
	}
	
	 public static BufferedImage joinBufferedImage(BufferedImage img1,
		      BufferedImage img2) {
		 
		 int offset = 2;
		    int width = img1.getWidth() + img2.getWidth() + offset;
		    int height = Math.max(img1.getHeight(), img2.getHeight()) + offset;
		    BufferedImage newImage = new BufferedImage(width, height,
		        BufferedImage.TYPE_INT_ARGB);
		    Graphics2D g2 = newImage.createGraphics();
		    Color oldColor = g2.getColor();
		    g2.setPaint(Color.BLACK);
		    g2.fillRect(0, 0, width, height);
		    g2.setColor(oldColor);
		    g2.drawImage(img1, null, 0, 0);
		    g2.drawImage(img2, null, img1.getWidth() + offset, 0);
		    g2.dispose();
				return newImage;
	 
	 }

}
