package com.trans.io.test;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;

import javax.imageio.ImageIO;

public class Test1 {

	public static void main(String[] args) throws IOException {/*
		// TODO Auto-generated method stub

		File source = new File("G:/gowtham/folder/");
		File dest = new File("G:/gowtham/folder/tar/b104309B.a01");
		Files.copy(source.toPath(), dest.toPath());
		String path = "G:/gowtham/folder/";
		File file = new File(path);
        File[] files = file.listFiles();
        try {
	        for(File f: files){
	            System.out.println(f.getName());
	        }
        }catch(Exception e) {
        	System.out.println("no files");
        }
		
	*/
		
		/*BufferedImage image = null;
        try {
          
            //URL url = new URL("G:/gowtham/destination/19043109AA/b104309B.a01.PNG");
            FileInputStream fin=new FileInputStream("G:/gowtham/destination/19043109AA/b104309B.a01.PNG");
            image = ImageIO.read(fin);
            
            ImageIO.write(image, "jpg",new File("G:/gowtham/destination/19043109AA/out.jpg"));
            ImageIO.write(image, "gif",new File("G:/gowtham/destination/19043109AA/out.gif"));
            ImageIO.write(image, "png",new File("G:/gowtham/destination/19043109AA/out.png"));
            
        } catch (IOException e) {
        	e.printStackTrace();
        }
        System.out.println("Done");*/
		
		File file = new File("G:/gowtham/destination/19043109AA/b104309B.a01.PNG");
		// ...(file is initialised)...
		byte[] fileContent = Files.readAllBytes(file.toPath());
		BufferedImage image = ImageIO.read(new ByteArrayInputStream(fileContent));
	    System.out.println("hji");
	    
	    
	    /*RandomAccessFile stream = new RandomAccessFile("G:/gowtham/destination/19043109AA/b104309BGows.PNG", "rw");
	    FileChannel channel = stream.getChannel();
	    ByteBuffer buffer = ByteBuffer.allocate(fileContent.length);
	    buffer.put(fileContent);
	    buffer.flip();
	    channel.write(buffer);
	    stream.close();
	    channel.close();*/
	
		/*FileOutputStream out = new FileOutputStream("G:/gowtham/destination/19043109AA/b104309BGows.PNG");
		out.write(fileContent);
		out.close();*/
		
		/*FileInputStream in=new FileInputStream("G:/gowtham/destination/19043109AA/b104309B.a01.PNG");
		JPEGImageDecoder decoder = JPEGCodec.create
		BufferedImage image = decoder.decodeAsBufferedImage();
		in.close();*/
		
		/*avax.swing.JFrame f; 
		
		String imgf1 = "G:\\gowtham\\destination\\19043109AA\\b104309B.a01.PNG";
		String imgf2 = "G:\\gowtham\\destination\\19043109AA\\b104309B.q01.PNG";
		Image i1 = Toolkit.getDefaultToolkit().createImage(imgf1);
		Image i2 = Toolkit.getDefaultToolkit().createImage(imgf2);
		
		BufferedImage bi = (BufferedImage)f.createImage(i1.getWidth(f),i1.getHeight(f));
		
		DataOutputStream outStream = new DataOutputStream(new FileOutputStream("G:/gowtham/destination/19043109AA/b104309BGows.PNG"));
	    outStream.write(fileContent);
	    outStream.close();*/
	
	
		
	
	}

}
